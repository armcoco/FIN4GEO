function val=rhog__(x,y)

val=1;