function ssolgp = solgp__(x,y)

ssolgp = 0;
