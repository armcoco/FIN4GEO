% Plot data 

% C_SP
SP=xlsread('/Users/jk18764/Desktop/Matlab_results/C_SP_new.xlsx','UnrestI');
t=SP(:,1);
t=t/86400;
SP1_ref=SP(1,7);
SP1_t=SP(:,7);
SP1a=SP(:,2); %1e-8
SP1b=SP(:,3); %1e-10
SP1c=SP(:,4); %-1e-8
SP1d=SP(:,5); %-1e-9
SP1e=SP(:,6); %-1e-10


SP2=xlsread('/Users/jk18764/Desktop/Matlab_results/C_SP_new.xlsx','UnrestII');
SP2_ref=SP2(1,7);
SP2_t=SP2(:,7);
SP2a=SP2(:,2); %1e-8
SP2b=SP2(:,3); %1e-10
SP2c=SP2(:,4); %-1e-8
SP2d=SP2(:,5); %-1e-9
SP2e=SP2(:,6); %-1e-10


SP3=xlsread('/Users/jk18764/Desktop/Matlab_results/C_SP_new.xlsx','UnrestIII');
SP3_ref=SP3(1,7);
SP3_t=SP3(:,7);
SP3a=SP3(:,2); %1e-8
SP3b=SP3(:,3); %1e-10
SP3c=SP3(:,4); %-1e-8
SP3d=SP3(:,5); %-1e-9
SP3e=SP3(:,6); %-1e-10

SP4=xlsread('/Users/jk18764/Desktop/Matlab_results/C_SP_new.xlsx','UnrestIV');
SP4_ref=SP4(1,7);
SP4_t=SP4(:,7);
SP4a=SP4(:,2); %1e-8
SP4b=SP4(:,3); %1e-10
SP4c=SP4(:,4); %-1e-8
SP4d=SP4(:,5); %-1e-9
SP4e=SP4(:,6); %-1e-10

SP5=xlsread('/Users/jk18764/Desktop/Matlab_results/C_SP_new.xlsx','UnrestV');
SP5=SP5(1:44,:);
SP5_ref=SP5(1,7);
SP5_t=SP5(:,7);
SP5a=SP5(:,2); %1e-8
SP5b=SP5(:,3); %1e-10
SP5c=SP5(:,4); %-1e-8
SP5d=SP5(:,5); %-1e-9
SP5e=SP5(:,6); %-1e-10


%Biot-Willis 
v1=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestI.xlsx','w');
u1=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestI.xlsx','u');
v1=v1(1:44,:);
u1=u1(1:44,:);
v1_ref=v1(1,5); 
v1_t=v1(1:44,5); 
v1a=v1(1:44,2); %2x
v1b=v1(1:44,3); %3x
v1c=v1(1:44,4); %4x
u1_ref=u1(1,5); 
u1_t=u1(1:44,5); 
u1a=u1(1:44,2); %2x
u1b=u1(1:44,3); %3x
u1c=u1(1:44,4); %4x

v2=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestII.xlsx','w');
u2=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestII.xlsx','u');
v2=v2(1:44,:);
u2=u2(1:44,:);
v2_ref=v2(1,5); 
v2_t=v2(1:44,5); 
v2a=v2(1:44,2); %2x
v2b=v2(1:44,3); %3x
v2c=v2(1:44,4); %4x
u2_ref=u2(1,5); 
u2_t=u2(1:44,5); 
u2a=u2(1:44,2); %2x
u2b=u2(1:44,3); %3x
u2c=u2(1:44,4); %4x

v3=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis.xlsx','w');
u3=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis.xlsx','u');
v3=v3(1:44,:);
u3=u3(1:44,:);
v3_ref=v3(1,5); 
v3_t=v3(1:44,5); 
v3a=v3(1:44,2); %2x
v3b=v3(1:44,3); %3x
v3c=v3(1:44,4); %4x
u3_ref=u3(1,5); 
u3_t=u3(1:44,5); 
u3a=u3(1:44,2); %2x
u3b=u3(1:44,3); %3x
u3c=u3(1:44,4); %4x


v4=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestIV.xlsx','w');
u4=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestIV.xlsx','u');
v4=v4(1:44,:);
u4=u4(1:44,:);
v4_ref=v4(1,5); 
v4_t=v4(1:44,5); 
v4a=v4(1:44,2); %2x
v4b=v4(1:44,3); %3x
v4c=v4(1:44,4); %4x
u4_ref=u4(1,5); 
u4_t=u4(1:44,5); 
u4a=u4(1:44,2); %2x
u4b=u4(1:44,3); %3x
u4c=u4(1:44,4); %4x

v5=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestV.xlsx','w');
u5=xlsread('/Users/jk18764/Desktop/Matlab_results/Biot_Willis_UnrestV.xlsx','u');
v5=v5(1:44,:);
u5=u5(1:44,:);
v5_ref=v5(1,5); 
v5_t=v5(1:44,5); 
v5a=v5(1:44,2); %2x
v5b=v5(1:44,3); %3x
v5c=v5(1:44,4); %4x
u5_ref=u5(1,5); 
u5_t=u5(1:44,5); 
u5a=u5(1:44,2); %2x
u5b=u5(1:44,3); %3x
u5c=u5(1:44,4); %4x


%Plot


figure(1)
%vertical displacement
subplot('Position',[.04 .78 .25 .20]) 
plot(t,[v1a./v1_ref,v2a./v2_ref,v3a./v3_ref,v4a./v4_ref,v5a./v5_ref],'-', 'LineWidth',2);
ylabel('Normalised Vertical Displacement','FontSize',14)
xlim([0 350])
hold on
subplot('Position',[.33 .78 .25 .20])  
plot(t,[v1b./v1_ref,v2b./v2_ref,v3b./v3_ref,v4b./v4_ref,v5b./v5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on
subplot('Position',[.62 .78 .25 .20]) 
plot(t,[v1c./v1_ref,v2c./v2_ref,v3c./v3_ref,v4c./v4_ref,v5c./v5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on
%Horizontal displacement
subplot('Position',[.04 .55 .25 .20]) 
plot(t,[u1a./u1_ref,u2a./u2_ref,u3a./u3_ref,u4a./u4_ref,u5a./u5_ref],'-', 'LineWidth',2);
ylabel('Normalised Horizontal Displacement','FontSize',14)
xlim([0 350])
hold on
subplot('Position',[.33 .55 .25 .20])  
plot(t,[u1b./u1_ref,u2b./u2_ref,u3b./u3_ref,u4b./u4_ref,u5b./u5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on
subplot('Position',[.62 .55 .25 .20]) 
plot(t,[u1c./u1_ref,u2c./u2_ref,u3c./u3_ref,u4c./u4_ref,u5c./u5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on
%SP
%SP
%1e-8
subplot('Position',[.04 .32 .25 .20]) 
plot(t,[SP1a./SP1_ref, SP2a./SP2_ref, SP3a./SP3_ref, SP4a./SP4_ref, SP5a./SP5_ref],'-', 'LineWidth',2);
ylabel('Normalised Self-Potential','FontSize',14)
xlim([0 350])
hold on
subplot('Position',[.33 .32 .25 .20])  
plot(t,[SP1_t./SP1_ref, SP2_t./SP2_ref, SP3_t./SP3_ref, SP4_t./SP4_ref, SP5_t./SP5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on
subplot('Position',[.62 .32 .25 .20]) 
plot(t,[SP1b./SP1_ref, SP2b./SP2_ref, SP3b./SP3_ref, SP4b./SP4_ref, SP5b./SP5_ref],'-', 'LineWidth',2);
xlim([0 350])
%Negavitve CSP
hold on
subplot('Position',[.04 .09 .25 .20]) 
plot(t,[ SP1c./SP1_ref, SP2c./SP2_ref, SP3c./SP3_ref, SP4c./SP4_ref, SP5c./SP5_ref],'-', 'LineWidth',2);
ylabel('Normalised Self-Potential','FontSize',14)
xlim([0 350])
hold on
subplot('Position',[.33 .09 .25 .20])  
plot(t,[ SP1d./SP1_ref, SP2d./SP2_ref, SP3d./SP3_ref, SP4d./SP4_ref, SP5d./SP5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on
subplot('Position',[.62 .09 .25 .20]) 
plot(t,[ SP1e./SP1_ref, SP2e./SP2_ref, SP3e./SP3_ref, SP4e./SP4_ref, SP5e./SP5_ref],'-', 'LineWidth',2);
xlim([0 350])
hold on






