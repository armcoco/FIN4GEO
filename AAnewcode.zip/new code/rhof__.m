function val=rhof__(x,y)

val=1;