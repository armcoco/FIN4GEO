function val=satur__(x,y)

val=1;