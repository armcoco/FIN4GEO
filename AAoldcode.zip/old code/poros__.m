function val=poros__(x,y)

val=1;