function ssolsp = solsp__(x,y)

ssolsp = 0;
