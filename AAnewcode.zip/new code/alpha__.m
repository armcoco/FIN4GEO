function salpha = alpha__(x,y)

global alpha alphaalpha
salpha = alphaalpha*alpha;
