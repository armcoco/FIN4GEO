function ssolu = solu__(x,y)

ssolu = 0;
