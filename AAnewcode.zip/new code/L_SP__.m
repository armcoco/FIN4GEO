function L_SP = L_SP__(x,y)

L_SP = zeros(size(x));

%HTS
k=find(x(:)<=50);
L_SP(k)=-1.*1e-9;

%Transition Zone
k=find(x(:)>50 & x(:)<150);
L_SP(k)=-0.3333.*1e-9;

%Edifice
k=find(x(:)>150);
L_SP(k)=-0.1.*1e-9;