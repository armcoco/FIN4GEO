function ssolv = solv__(x,y)

ssolv = 0;
