function sbeta = beta__(x,y)
% 
beta= zeros(size(x));
% 
%HTS
k=find(x(:)<=50);
beta(k)=0.2;

% Transition Zone
 k=find(x(:)>50 & x(:)<150);
 beta(k)=0.15;
% 
% Edifice
 k=find(x(:)>150);
 beta(k)=0.1;
%global beta
sbeta = beta;
