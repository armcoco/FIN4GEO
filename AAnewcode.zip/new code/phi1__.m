function sphi1 = phi1__(x,y)

sphi = zeros(size(x));

% flat topography
sphi1 = y;

% exponential decay
sphi1 = y - 3e3*exp(-(x/1e3).^2);

% Ruapehu
% [ai]=find(x(:)>=0 & x(:)<=50);
% sphi1(ai) = y(ai) - 2440;
% % %all below r - 500 m
% [ai]=find (x(:)>50 & x(:)<500);
% sphi1(ai) = y(ai) - (2440 + (2640-2460)/500*(x(ai)-50));
% %flat surface/plateau
% [ai]=find(x(:)>=500 & x(:)<1300);
% sphi1(ai) = y(ai) - 2640;
% %expotential decay after plateau
% [ai]=find(x(:)>=1300 & x(:)<5500);
% sphi1(ai) = y(ai) - (2640 + (1500-2640)/(5500-1300)*(x(ai)-1300));
% %flat surface for r > 5.5 km
% [ai]=find(x(:)>=5500);
% sphi1(ai) = y(ai) - 1500;

% %Test new
[ai]=find(x(:)>=0 & x(:)<50);
sphi1(ai) = y(ai) - 2440;
% %all below r - 500 m
[ai]=find (x(:)>=50 & x(:)<=500);
sphi1(ai) = y(ai) - (2440 + (2640-2440)/(500-59)*(x(ai)-59));
%flat surface/plateau
[ai]=find(x(:)>500 & x(:)<1300);
sphi1(ai) = y(ai) - 2640;
%expotential decay after plateau
[ai]=find(x(:)>=1300 & x(:)<5500);
sphi1(ai) = y(ai) - (2640 + (1500-2640)/(5500-1300)*(x(ai)-1300));
%flat surface for r > 5.5 km
[ai]=find(x(:)>=5500);
sphi1(ai) = y(ai) - 1500;

% %all below r - 500 m
% [ai]=find(x(:)<500);
% sphi1(ai) = y(ai) - (2440 + (2640-2440)/500*x(ai));
% %flat surface/plateau
% [ai]=find(x(:)>=500 & x(:)<1300);
% sphi1(ai) = y(ai) - 2640;
% %expotential decay after plateau
% [ai]=find(x(:)>=1300 & x(:)<5500);
% sphi1(ai) = y(ai) - (2640 + (1500-2640)/(5500-1300)*(x(ai)-1300));
% %flat surface for r > 5.5 km
% [ai]=find(x(:)>=5500);
% sphi1(ai) = y(ai) - 1500;
