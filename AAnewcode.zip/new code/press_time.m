function P=press_time(t)

P=20e6*(1-1/(10*t+1));