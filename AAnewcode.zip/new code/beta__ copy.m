function sbeta = beta__(x,y)

global beta
sbeta = beta;
