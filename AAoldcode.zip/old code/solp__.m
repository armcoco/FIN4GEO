function ssolp = solp__(x,y)

ssolp = zeros(size(x));
