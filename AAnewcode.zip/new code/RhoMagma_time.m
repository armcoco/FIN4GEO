function RhoMagma=RhoMagma_time(t)

RhoMagma=2350; % from papers

RhoMagma=2350-0.9*2000-0.1*1000;
% RhoMagma=500*1.8745*1.3*0.91;

% RhoMagma=1.122584249886633e+04;
% 
% RhoMagma=350;