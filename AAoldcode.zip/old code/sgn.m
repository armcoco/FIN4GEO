function y=sgn(x)

if x==0
    y=1; return;
end

y=sign(x);