figure
% plot(Xu(Inside.all),Yu(Inside.all),'*b');
plot(Xu,Yu,'*b');
hold on
plot([0 4500],[-6500 -6500],'r-')
plot([0 4500],[-6500.3 -6500.3],'r-')
plot([4500 4500],[-6500.3 -6500],'r-')
plot([0 1e5],[0 0],'r-')